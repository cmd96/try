package com.test;

public class User {
    public static String getUserFirstName(String user, int password){

        return user;
    }
}
